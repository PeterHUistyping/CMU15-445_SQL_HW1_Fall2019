SELECT distinct(type) FROM titles ORDER BY type;
